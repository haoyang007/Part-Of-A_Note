package com.example.finmins.materialtest;

/**
 * Created by hhhao on 2020/2/20.
 */
public enum  DrawMode {
    //画笔模式
    PaintMode,
    //橡皮擦模式
    EraserMode,
}