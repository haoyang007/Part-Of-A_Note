package com.example.finmins.materialtest

fun main(){
    println("hello，world!");
}